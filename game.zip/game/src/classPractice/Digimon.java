package classPractice;

import java.util.Random;

public class Digimon {
	
	String[] rank = {"아구몬", "그레이몬", "메탈그레이몬", "워그레이몬"};
	
	String name;
	int hp;
	int exp;
	int feedCount;
	int rankNumber;
	
	public Digimon(String name) {
		this.name = name;
		hp = 11;
		feedCount = 10;
	}
	
	void sleep() {
		System.out.print(rank[rankNumber] + "(이)가 잠자는 중");
		for (int i = 0; i < 3; i++) {
			try {Thread.sleep(1000);} catch (InterruptedException e) {;}
			System.out.print("...");
		}
		System.out.println("\n아이고 잘잤다!\n");
		hp += hp + 3;
	}
	
	void doEvolution() {
		if(rankNumber == 3) {
			System.out.println("이미 최종 단계입니다!\n");
			return;
		}
		
		if(exp < 10) {
			System.out.println("경험치를 더 채우고 와!");
		} else {
			System.out.println(rank[rankNumber] + " 진화!!!!");
			for (int i = 0; i < 3; i++) {
				try {Thread.sleep(1000);} catch (InterruptedException e) {;}
				System.out.print("...");
			}
			rankNumber++;
			exp = 0;
			hp = 11;
			System.out.println("\n" +rank[rankNumber] + " 등장!!!!\n");			
		}
	}
	
	void eat() {
		if(feedCount < 1) {
			System.out.println("음식이 없어요... ㅠㅠ\n");
			return;
		}
		feedCount--;
		hp += hp + 2;
	}
	
	void fight() {
		if(hp < 5) {
			System.out.println("먹기나 잠자기를 통해서 hp를 회복해주세요!\n");
		} else {
			Random r = new Random();
			int[] percent = new int[10];
			int rating = 50;
			
			System.out.println("싸움을 시작해볼까!?!?\n");
			
			for (int i = 0; i < rating / 10; i++) {
				percent[i] = 1;
			}
			
			if(percent[r.nextInt(percent.length)] == 1) { // 사냥 대성공!
				System.out.println("이 구역의 적들을 쓸어버렸어!");
				exp = 10;
				
			} else { // 일반 적인 사냥
				System.out.println("힘든 싸움이였다...");
				hp -= 5;
				exp += 5;
			}			
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
